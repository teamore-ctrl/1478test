# posix-mmap

This library implements the POSIX memory mapping related functions such as
`mmap()`, `mprotect()`, and `madvise()`. The implementation is basically just
a wrapper around `ukvmem`.
