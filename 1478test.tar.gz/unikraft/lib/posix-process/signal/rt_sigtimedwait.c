/* SPDX-License-Identifier: BSD-3-Clause */
/* Copyright (c) 2023, Unikraft GmbH and The Unikraft Authors.
 * Licensed under the BSD-3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 */

#include <signal.h>
#include <stdlib.h>
#include <sys/time.h>

#include <uk/essentials.h>
#include <uk/syscall.h>
#include <uk/timeutil.h>

#if !CONFIG_LIBPOSIX_PROCESS_SIGNAL
#include <uk/plat/time.h>
#include <uk/sched.h>
#endif /* !CONFIG_LIBPOSIX_PROCESS_SIGNAL */

#include "process.h"
#include "signal.h"

#if CONFIG_LIBPOSIX_PROCESS_SIGNAL
UK_LLSYSCALL_R_DEFINE(int, rt_sigtimedwait,
		      const uk_sigset_t *, set,
		      siginfo_t *, info,
		      const struct timespec *, timeout,
		      size_t, sigsetsize)
{
	struct posix_thread *pthread;
	struct uk_signal *sig;

	if (unlikely(!set))
		return -EINVAL;

	if (unlikely(sigsetsize != sizeof(sigset_t)))
		return -EINVAL;

	pthread = uk_pthread_current();
	UK_ASSERT(pthread);

	/* TODO protect concurrent access by deliver_pending_proc() */
	uk_sigcopyset(&pthread->signal->sigwait_set, set);

	/* If a signal in the set is already pending return immediately */
	if ((sig = pprocess_signal_next_pending_t(pthread)))
		goto out;

	if (timeout) {
		if (unlikely(!(uk_time_spec_canonical(timeout) &&
			       uk_time_spec_positive(timeout))))
			return -EINVAL;
		uk_semaphore_down_to(&pthread->signal->pending_semaphore,
				     uk_time_spec_to_nsec(timeout));
	} else {
		uk_semaphore_down(&pthread->signal->pending_semaphore);
	}

	if ((sig = pprocess_signal_next_pending_t(pthread)))
		goto out;

	return -EAGAIN;
out:
	if (info)
		*info = sig->siginfo;
	uk_sigemptyset(&pthread->signal->sigwait_set);
	return sig->siginfo.si_signo;
}
#else /* !CONFIG_LIBPOSIX_PROCESS_SIGNAL */
UK_LLSYSCALL_R_DEFINE(int, rt_sigtimedwait,
		      const uk_sigset_t *, set,
		      siginfo_t *, info,
		      const struct timespec *, timeout,
		      size_t, sigsetsize)
{
	struct uk_thread *current = uk_thread_current();
	__nsec timeout_ns;
	int rc;

	if (timeout) {
		if (unlikely(!(uk_time_spec_canonical(timeout) &&
			       uk_time_spec_positive(timeout))))
			return -EINVAL;
		timeout_ns = ukplat_monotonic_clock() +
			ukarch_time_sec_to_nsec(timeout->tv_sec) +
			timeout->tv_nsec;
		uk_thread_block_until(current, (__snsec)timeout_ns);
		uk_sched_yield();
		rc = -EAGAIN;
	} else {
		uk_thread_block(current);
		uk_sched_yield();
		/* If this ever returns then just return an EINTR to not
		 * confuse the application
		 */
		rc = -EINTR;
	}

	/* We currently never return a signal */
	*info = (siginfo_t){0};
	return rc;
}
#endif /* !CONFIG_LIBPOSIX_PROCESS_SIGNAL */
